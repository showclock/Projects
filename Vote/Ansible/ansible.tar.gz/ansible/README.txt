Ansible  Installation Guide https://docs.ansible.com/ansible/latest/installation_guide/intro_installation.html

tar zxvf ansible.tar.gz

cd ansible

ansible-playbook playbook.yml
